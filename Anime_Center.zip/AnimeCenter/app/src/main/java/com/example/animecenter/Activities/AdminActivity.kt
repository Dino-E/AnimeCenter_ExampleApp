package com.example.animecenter.Activities

import android.os.Bundle
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.animecenter.Adapters.BannerAdapter
import com.example.animecenter.Domains.Banner
import com.example.animecenter.R
import com.google.firebase.Firebase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

class AdminActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var recyclerView: RecyclerView
    private lateinit var bannerAdapter: BannerAdapter
    private var bannerList: MutableList<Banner> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val window = window
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        database = Firebase.database.reference.child("Banners")
        recyclerView = findViewById(R.id.recyclerViewBanners)
        recyclerView.layoutManager = LinearLayoutManager(this)
        bannerAdapter = BannerAdapter(bannerList, ::editBanner, ::deleteBanner)
        recyclerView.adapter = bannerAdapter

        findViewById<Button>(R.id.btnAddBanner).setOnClickListener {
            showAddBannerDialog()
        }

        loadBanners()
    }

    private fun loadBanners() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                bannerList.clear()
                for (bannerSnapshot in snapshot.children) {
                    val banner = bannerSnapshot.getValue(Banner::class.java)
                    if (banner != null) {
                        bannerList.add(banner)
                    }
                }
                bannerAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@AdminActivity, "Failed to load banners.", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showAddBannerDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_banner, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setTitle("Agregar Banner")
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.show()

        val btnSubmit = dialogView.findViewById<AppCompatButton>(R.id.btnSubmit)

        btnSubmit.setOnClickListener {
            val name = dialogView.findViewById<EditText>(R.id.editTextName).text.toString()
            val genre = dialogView.findViewById<EditText>(R.id.editTextGenre).text.toString()
            val age = dialogView.findViewById<EditText>(R.id.editTextAge).text.toString()
            val time = dialogView.findViewById<EditText>(R.id.editTextTime).text.toString()
            val year = dialogView.findViewById<EditText>(R.id.editTextYear).text.toString()
            val imageUrl = dialogView.findViewById<EditText>(R.id.editTextImageUrl).text.toString()

            if (name.isNotEmpty() && genre.isNotEmpty() && age.isNotEmpty() && time.isNotEmpty() && year.isNotEmpty() && imageUrl.isNotEmpty()) {
                val newBanner = Banner(name, age, genre, imageUrl, name, time, year)
                database.child(name).setValue(newBanner)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun editBanner(banner: Banner) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_banner, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setTitle("Editar Banner")
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.show()

        val nameView = dialogView.findViewById<EditText>(R.id.editTextName)
        val genreView = dialogView.findViewById<EditText>(R.id.editTextGenre)
        val ageView = dialogView.findViewById<EditText>(R.id.editTextAge)
        val timeView = dialogView.findViewById<EditText>(R.id.editTextTime)
        val yearView = dialogView.findViewById<EditText>(R.id.editTextYear)
        val imageUrlView = dialogView.findViewById<EditText>(R.id.editTextImageUrl)
        val btnSubmit = dialogView.findViewById<AppCompatButton>(R.id.btnSubmit)

        nameView.setText(banner.name)
        genreView.setText(banner.genre)
        ageView.setText(banner.age)
        timeView.setText(banner.time)
        yearView.setText(banner.year)
        imageUrlView.setText(banner.image)

        btnSubmit.setOnClickListener {
            val name = nameView.text.toString()
            val genre = genreView.text.toString()
            val age = ageView.text.toString()
            val time = timeView.text.toString()
            val year = yearView.text.toString()
            val imageUrl = imageUrlView.text.toString()

            if (name.isNotEmpty() && genre.isNotEmpty() && age.isNotEmpty() && time.isNotEmpty() && year.isNotEmpty() && imageUrl.isNotEmpty()) {
                val updatedBanner = Banner(name, age, genre, imageUrl, name, time, year)
                database.child(name).setValue(updatedBanner)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun deleteBanner(banner: Banner) {
        database.child(banner.name).removeValue()
    }
}
