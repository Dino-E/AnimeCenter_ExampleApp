package com.example.animecenter.Domains

data class Banner(
    val id: String = "",
    val age: String = "",
    val genre: String = "",
    val image: String = "",
    val name: String = "",
    val time: String = "",
    val year: String = ""
)
