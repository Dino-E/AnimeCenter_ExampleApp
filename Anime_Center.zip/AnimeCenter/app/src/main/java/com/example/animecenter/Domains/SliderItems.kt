package com.example.animecenter.Domains

data class SliderItems(
    val image: String = "",
    val age: String = "",
    val name: String = "",
    val genre: String = "",
    val year: String = "",
    val time: String = ""
)
