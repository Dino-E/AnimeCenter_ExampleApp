package com.example.animecenter.Adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.example.animecenter.Domains.SliderItems
import com.example.animecenter.R

class SlidersAdapter(
    private val sliderItems: List<SliderItems>,
    private val viewPager2: ViewPager2
) : RecyclerView.Adapter<SlidersAdapter.SliderViewHolder>() {

    private lateinit var context: Context

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SliderViewHolder {
        context = parent.context
        val view = LayoutInflater.from(context).inflate(R.layout.slider_viewholder, parent, false)
        return SliderViewHolder(view)
    }

    override fun onBindViewHolder(holder: SliderViewHolder, position: Int) {
        val realPosition = position % sliderItems.size
        holder.setImage(sliderItems[realPosition])
    }

    override fun getItemCount(): Int {
        return Int.MAX_VALUE  // Número grande para simular bucle infinito
    }

    inner class SliderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imageView: ImageView = itemView.findViewById(R.id.imageSlide)
        private val nameTxt: TextView = itemView.findViewById(R.id.nameTxt)
        private val genreTxt: TextView = itemView.findViewById(R.id.genreTxt)
        private val yearTxt: TextView = itemView.findViewById(R.id.yearTxt)
        private val timeTxt: TextView = itemView.findViewById(R.id.timeTxt)
        private val ageTxt:  TextView = itemView.findViewById(R.id.ageTxt)


        fun setImage(sliderItems: SliderItems) {
            val requestOptions = RequestOptions().transform(CenterCrop(), RoundedCorners(60))
            Glide.with(context)
                .load(sliderItems.image)
                .apply(requestOptions)
                .into(imageView)
            nameTxt.text = sliderItems.name
            genreTxt.text = sliderItems.genre
            yearTxt.text = sliderItems.year
            timeTxt.text = sliderItems.time
            ageTxt.text = sliderItems.age
        }
    }
}
