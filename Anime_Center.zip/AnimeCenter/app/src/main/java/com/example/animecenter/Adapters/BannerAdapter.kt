package com.example.animecenter.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.animecenter.Domains.Banner
import com.example.animecenter.R
import com.squareup.picasso.Picasso

class BannerAdapter(
    private val banners: List<Banner>,
    private val onEditBanner: (Banner) -> Unit,
    private val onDeleteBanner: (Banner) -> Unit
) : RecyclerView.Adapter<BannerAdapter.BannerViewHolder>() {

    class BannerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.bannerImage)
        val nameView: TextView = itemView.findViewById(R.id.bannerName)
        val genreView: TextView = itemView.findViewById(R.id.bannerGenre)
        val yearView: TextView = itemView.findViewById(R.id.bannerYear)
        val editButton: Button = itemView.findViewById(R.id.btnEdit)
        val deleteButton: Button = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BannerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_banner, parent, false)
        return BannerViewHolder(view)
    }

    override fun onBindViewHolder(holder: BannerViewHolder, position: Int) {
        val banner = banners[position]
        holder.nameView.text = banner.name
        holder.genreView.text = banner.genre
        holder.yearView.text = banner.year
        Picasso.get().load(banner.image).into(holder.imageView)
        holder.editButton.setOnClickListener { onEditBanner(banner) }
        holder.deleteButton.setOnClickListener { onDeleteBanner(banner) }
    }

    override fun getItemCount(): Int = banners.size
}
