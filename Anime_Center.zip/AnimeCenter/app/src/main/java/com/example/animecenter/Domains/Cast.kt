package com.example.animecenter.Domains

import java.io.Serializable

data class Cast(
    val Actor: String = "",
    val PicUrl: String = ""
) : Serializable {
    // Constructor sin argumentos
    constructor() : this("", "")
}

