package com.example.animecenter.Activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.GranularRoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.example.animecenter.Adapters.CategoryEachAnimeAdapter
import com.example.animecenter.Adapters.CastListAdapter
import com.example.animecenter.Domains.Anime
import com.example.animecenter.databinding.ActivityDetailBinding
import eightbitlab.com.blurview.RenderScriptBlur

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        setVariable()
    }

    private fun setVariable() {
        val item = intent.getSerializableExtra("object") as? Anime
        val requestOptions = RequestOptions().transform(CenterCrop(), GranularRoundedCorners(0f, 8f, 50f, 50f))

        Glide.with(this)
            .load(item?.Poster)
            .apply(requestOptions)
            .into(binding.animePic)

        binding.titleTxt.text = item?.Title
        binding.imdbTxt.text = "IMDB ${item?.Imdb}"
        binding.animeTimesTxt.text = "${item?.Year} - ${item?.Time}"
        binding.animeSummery.text = item?.Description

        binding.watchTrailerBtn.setOnClickListener {
            val id = item?.Trailer?.replace("https://www.youtube.com/watch?v=", "") ?: ""
            val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$id"))
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(item?.Trailer))

            try {
                startActivity(appIntent)
            } catch (ex: ActivityNotFoundException) {
                startActivity(webIntent)
            }
        }

        binding.backImg.setOnClickListener {
            finish()
        }

        val radius = 10f
        val decorView = window.decorView
        val rootView = decorView.findViewById<ViewGroup>(android.R.id.content)
        val windowsBackground = decorView.background

        binding.blurView.setupWith(rootView, RenderScriptBlur(this))
            .setFrameClearDrawable(windowsBackground)
            .setBlurRadius(radius)
        binding.blurView.outlineProvider = ViewOutlineProvider.BACKGROUND
        binding.blurView.clipToOutline = true

        item?.Genre?.let { genreList ->
            if (genreList.isNotEmpty()) {
                binding.genreView.adapter = CategoryEachAnimeAdapter(genreList)
                binding.genreView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            }
        }

        item?.Casts?.let { castList ->
            if (castList.isNotEmpty()) {
                binding.CastView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
                binding.CastView.adapter = CastListAdapter(castList)
            }
        }
    }
}
