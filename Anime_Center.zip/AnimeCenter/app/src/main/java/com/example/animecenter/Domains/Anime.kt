package com.example.animecenter.Domains

import java.io.Serializable

data class Anime(
    val Title: String = "",
    val Description: String = "",
    val Poster: String = "",
    val Time: String = "",
    val Year: Int = 0,
    val Imdb: Double = 0.0,
    val Trailer: String = "",
    val Genre: List<String> = emptyList(),
    val Casts: List<Cast> = emptyList()
) : Serializable {
    // Constructor sin argumentos
    constructor() : this("", "", "", "", 0, 0.0, "", emptyList(), emptyList())
}
